import {ProjectDetailSkeleton} from "@/components/skeleton/root-skeleton";

export default function RootLoading() {
  return <ProjectDetailSkeleton />
}
