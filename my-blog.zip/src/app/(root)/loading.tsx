import { TopLoadingBar } from "@/components/skeleton/top-loading-bar"

export default function RootLoading() {
  return <TopLoadingBar />
}
