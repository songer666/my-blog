import {Loading} from '@/components/skeleton/admin-skeleton'

export default function AdminLoading(){
    return <Loading/>
}