import { BlogDetailSkeleton } from '@/components/skeleton/root-skeleton';

export default function Loading() {
  return <BlogDetailSkeleton />;
}
