export { Pagination } from './pagination';
export type { PaginationProps } from './type';
